package com.devsuperior.workshopcassandra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkshopcassandraApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkshopcassandraApplication.class, args);
	}

}
