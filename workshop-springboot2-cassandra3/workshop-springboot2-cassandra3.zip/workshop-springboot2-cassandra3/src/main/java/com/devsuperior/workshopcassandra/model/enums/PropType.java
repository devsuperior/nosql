package com.devsuperior.workshopcassandra.model.enums;

public enum PropType {

	PRODUCT, CONDITION;
}
