package com.devsuperior.workshopcassandra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkshopcassandraApplicationTests {

	@Test
	void contextLoads() {
	}

}
